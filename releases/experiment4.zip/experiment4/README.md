# Recommended specification:
	python - 3.7.4
	numpy - 1.19.4
	cudatoolkit - 10.2.89
	cudnn - 7.6.5
	pytorch - 1.7.0

These codes are designed to run in a multi-GPU environment. If it is not available for you, please pay attention to the variable "device_id".

Please run each .py file separately in the project path.

Larger datasets like MNIST are not contained in the "datasets" folder. Please redirect routes inside the codes.

For experiment 4, result generation and curve generation are valid only for GAN and WGAN model.
